from fastapi import FastAPI, Form, Request, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import pandas as pd
#import plotly.express as px
import matplotlib.pyplot as plt
import base64
from io import BytesIO

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

import matplotlib.pyplot as plt
from io import BytesIO
import base64

@app.post("/visualize/")
async def visualize(file: UploadFile = File(...), attributes: str = Form(...)):
    try:
        attributes_list = attributes.split(',')
        df = pd.read_csv(BytesIO(file.file.read()))

        fig, ax = plt.subplots()
        for attr in attributes_list:
            ax.plot(df['DeviceTimeStamp'], df[attr], label=attr)
        ax.set_title('Time Series Data')
        ax.legend()

        img = BytesIO()
        fig.savefig(img, format='png')
        img.seek(0)
        graph_url = base64.b64encode(img.getvalue()).decode()

        return {"graph_html": f'<img src="data:image/png;base64,{graph_url}" />'}
    except Exception as e:
        print(f"Error occurred: {e}")
        raise HTTPException(status_code=400, detail=f"Error processing the file: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)


