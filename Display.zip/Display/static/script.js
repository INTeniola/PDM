// static/script.js
document.getElementById('upload-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData();
    const fileInput = document.getElementById('file');
    const attributes = Array.from(document.getElementById('attributes').selectedOptions).map(option => option.value);
    formData.append('file', fileInput.files[0]);
    formData.append('attributes', attributes.join(','));

    fetch('/visualize/', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.detail) {
            document.getElementById('error-message').innerText = data.detail;
            document.getElementById('error-message').style.display = 'block';
        } else {
            document.getElementById('error-message').style.display = 'none';
            document.getElementById('graph').innerHTML = data.graph_html;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('error-message').innerText = 'An error occurred. Please try again.';
        document.getElementById('error-message').style.display = 'block';
    });
});
