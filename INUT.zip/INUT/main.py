from fastapi import FastAPI, Form, Request, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from typing import List

# Initialize FastAPI app
app = FastAPI()

# Mount static files (e.g., CSS, JS) and templates directory
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Define homepage route
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request}) 

# Define prediction endpoint
@app.post("/visualize/")
async def predict(file: UploadFile = File(...), attributes: List[str] = Form(...)):
    try:
        # Read uploaded CSV file
        df = pd.read_csv(file.file)
        
        predictions = {}
        anomalies = {}

        for attr in attributes:
            if attr not in df.columns:
                return {"error": f"CSV file must contain '{attr}' column"}

            # Perform forecasting using the ARIMA model
            history = list(df[attr].values)
            attr_predictions = []

            for t in range(7):  # Predict next 7 time steps
                model = ARIMA(history, order=(5, 1, 0))
                model_fit = model.fit()
                output = model_fit.forecast(steps=1)
                yhat = output[0]
                attr_predictions.append(yhat)
                history.append(yhat)

            predictions[attr] = attr_predictions

            # Calculate mean and standard deviation of historical values
            mean = np.mean(df[attr])
            std_dev = np.std(df[attr])
            upper_threshold = mean + 2 * std_dev
            lower_threshold = mean - 2 * std_dev

            # Identify anomalies
            attr_anomalies = [pred for pred in attr_predictions if pred > upper_threshold or pred < lower_threshold]
            anomalies[attr] = attr_anomalies

        # Return predictions and anomalies as JSON
        return {
            "historical": {attr: df[attr].tolist() for attr in attributes},
            "predictions": predictions,
            "anomalies": anomalies
        }

    except Exception as e:
        return {"error": str(e)}

# If running this script directly, run the app
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)

