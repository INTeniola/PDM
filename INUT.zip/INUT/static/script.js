// Handle form submission
document.getElementById('upload-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData();
    const fileInput = document.getElementById('file');
    const attributes = Array.from(document.getElementById('attributes').selectedOptions).map(option => option.value);
    formData.append('file', fileInput.files[0]);
    formData.append('attributes', attributes);

    // Perform AJAX request to server
    fetch('/visualize/', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
            return;
        }

        // Clear existing chart if any
        document.getElementById('prediction-chart').remove();
        document.getElementById('prediction-result').innerHTML = '<canvas id="prediction-chart"></canvas>';

        // Prepare data for visualization
        const labels = Array.from({ length: data.historical[Object.keys(data.historical)[0]].length + 7 }, (_, i) => i + 1);
        const datasets = [];

        for (const attr in data.historical) {
            datasets.push({
                label: `${attr} Historical Values`,
                data: data.historical[attr],
                borderColor: getRandomColor(),
                fill: false
            });

            datasets.push({
                label: `${attr} Predicted Values`,
                data: Array(data.historical[attr].length).fill(null).concat(data.predictions[attr]),
                borderColor: getRandomColor(),
                fill: false
            });

            const anomalies = data.predictions[attr].map((value, index) => {
                const length = data.historical[attr].length;
                if (data.anomalies[attr].includes(value)) {
                    return {x: length + index, y: value};
                }
                return null;
            }).filter(x => x !== null);

            datasets.push({
                label: `${attr} Anomalies`,
                data: anomalies,
                borderColor: 'orange',
                backgroundColor: 'orange',
                pointRadius: 5,
                type: 'scatter'
            });
        }

        // Visualize the results using Chart.js
        const ctx = document.getElementById('prediction-chart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Time Steps'
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Values'
                        }
                    }
                }
            }
        });
    })
    .catch(error => {
        console.error('Error:', error);
        const predictionResult = document.getElementById('prediction-result');
        predictionResult.innerHTML = `<p>Error occurred. Please try again.</p>`;
    });
});

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

