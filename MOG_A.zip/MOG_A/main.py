from fastapi import FastAPI, Form, Request, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import pandas as pd
import joblib
from typing import List

# Initialize FastAPI app
app = FastAPI()

# Mount static files (e.g., CSS, JS) and templates directory
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Load the pre-trained SVC model
svc_model = joblib.load('svc_model.pkl')

# Define homepage route
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# Define prediction endpoint
@app.post("/predict/")
async def predict(file: UploadFile = File(...)):
    try:
        # Read uploaded CSV file
        df = pd.read_csv(file.file)
        
        # Check if the required columns are in the uploaded file
        required_columns = ['OTI', 'WTI', 'OLI']
        for col in required_columns:
            if col not in df.columns:
                return {"error": f"CSV file must contain '{col}' column"}
        
        # Extract the required features for prediction
        X = df[required_columns]
        
        # Perform prediction
        predictions = svc_model.predict(X)
        
        # Return predictions as JSON
        return {
            "predictions": predictions.tolist()
        }

    except Exception as e:
        return {"error": str(e)}

# If running this script directly, run the app
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8080)
