// Handle form submission
document.getElementById('upload-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData();
    const fileInput = document.getElementById('file');
    formData.append('file', fileInput.files[0]);

    // Perform AJAX request to server
    fetch('/predict/', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
            return;
        }

        // Clear existing chart if any
        document.getElementById('prediction-chart').remove();
        document.getElementById('prediction-result').innerHTML = '<canvas id="prediction-chart"></canvas>';

        // Prepare data for visualization
        const labels = Array.from({ length: data.predictions.length }, (_, i) => i + 1);
        const predictions = data.predictions;

        // Visualize the results using Chart.js
        const ctx = document.getElementById('prediction-chart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'MOG_A Predictions',
                    data: predictions,
                    borderColor: 'blue',
                    fill: false
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Time Steps'
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Predicted Values'
                        }
                    }
                }
            }
        });
    })
    .catch(error => {
        console.error('Error:', error);
        const predictionResult = document.getElementById('prediction-result');
        predictionResult.innerHTML = `<p>Error occurred. Please try again.</p>`;
    });
});

