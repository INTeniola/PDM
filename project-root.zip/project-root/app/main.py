from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from datetime import datetime, timedelta

app = FastAPI()
templates = Jinja2Templates(directory="app/templates")

# Load the data
data = pd.read_csv("data/overall.csv", parse_dates=["Date"])

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/forecast", response_class=HTMLResponse)
async def forecast(request: Request, feature: str = Form(...), period: int = Form(...)):
    # Subset the data to the specific feature
    time_series = data[['Date', feature]].set_index('Date')
    
    # Fit an ARIMA model
    model = ARIMA(time_series, order=(5, 1, 0))  # You can modify the order parameters (p, d, q) based on your needs
    model_fit = model.fit()
    
    # Forecast the future values
    forecast = model_fit.forecast(steps=period)
    forecast_dates = pd.date_range(start=time_series.index[-1], periods=period+1, closed='right')
    
    forecast_df = pd.DataFrame({'Date': forecast_dates, 'Forecast': forecast})
    
    return templates.TemplateResponse("forecast.html", {"request": request, "forecast_df": forecast_df.to_dict(orient='records')})
