from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd
import joblib
import plotly.graph_objects as go
from starlette.middleware.cors import CORSMiddleware
import logging
from fastapi import HTTPException

app = FastAPI()
# Setup logging
logging.basicConfig(level=logging.INFO)
# Allow CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Load the trained model
model = joblib.load('best_rf_model.pkl')

@app.get("/", response_class=HTMLResponse)
async def read_index():
    with open("templates/index.html") as f:
        return f.read()

@app.post("/predict/")
async def predict(file: UploadFile = File(...)):
    try:
        # Log the incoming file
        logging.info(f"Received file: {file.filename}")

        df = pd.read_csv(file.file)

        # Log the first few rows of the dataframe to ensure it's being read correctly
        logging.info(f"Dataframe head:\n{df.head()}")

        # Feature engineering
        df['WTI_lag1'] = df['WTI'].shift(1)
        df['OTI_lag1'] = df['OTI'].shift(1)
        df['ATI_lag1'] = df['ATI'].shift(1)
        df.dropna(inplace=True)

        features = ['WTI_lag1', 'OTI_lag1', 'ATI_lag1', 'OTI', 'ATI']
        X = df[features]

        # Make predictions
        predictions = model.predict(X)
        df['WTI_Predictions'] = predictions

        # Log the predictions
        logging.info(f"Predictions:\n{df[['DeviceTimeStamp', 'WTI_Predictions']].head()}")

        # Return predictions
        return df[['DeviceTimeStamp', 'WTI', 'WTI_Predictions']].to_dict(orient='records')

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        raise HTTPException(status_code=400, detail=f"An error occurred: {str(e)}")


