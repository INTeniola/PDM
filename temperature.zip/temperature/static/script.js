document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('upload-form').addEventListener('submit', async function(event) {
        event.preventDefault();

        // Ensure plot-type element exists and is accessed correctly
        const plotTypeElement = document.getElementById('plot-type');
        if (!plotTypeElement) {
            alert("Plot type selection not found!");
            return;
        }

        const plotType = plotTypeElement.value; // Get the selected value safely

        const formData = new FormData();
        formData.append('file', document.getElementById('file').files[0]);

        try {
            const response = await fetch('/predict/', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.error) {
                alert("Error: " + data.error);
                return;
            }

            const timestamps = data.map(item => item.DeviceTimeStamp);
            const actualWTI = data.map(item => item.WTI);
            const predictedWTI = data.map(item => item.WTI_Predictions);

            const actualTrace = {
                x: timestamps,
                y: actualWTI,
                type: 'scatter',
                mode: plotType === 'dots' ? 'markers' : 'lines',
                name: 'Actual WTI'
            };

            const predictedTrace = {
                x: timestamps,
                y: predictedWTI,
                type: 'scatter',
                mode: plotType === 'dots' ? 'markers' : 'lines',
                name: 'Predicted WTI',
                yaxis: 'y2'
            };

            const layout = {
                title: 'WTI Prediction',
                xaxis: {
                    title: 'Timestamp',
                    range: [timestamps[0], timestamps[timestamps.length - 1]],
                    rangeslider: {visible: true},
                    type: 'date'
                },
                yaxis: {title: 'Actual WTI'},
                yaxis2: {
                    title: 'Predicted WTI',
                    overlaying: 'y',
                    side: 'right'
                },
                showlegend: true
            };

            Plotly.newPlot('chart', [actualTrace, predictedTrace], layout);
        } catch (error) {
            alert("An error occurred: " + error.message);
            console.error("Error:", error);
        }
    });
});