from fastapi import FastAPI, Request, APIRouter
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import joblib
import os


app = FastAPI()

static_dir = os.path.join(os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


# Jinja2 templates setup
templates = Jinja2Templates(directory="backend/templates")

@app.get("/")
async def get_dashboard(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# Define your API routes
router = APIRouter()

class InputData(BaseModel):
    oti: float
    wti: float
    ati: float
    # add other fields here

@router.post("/predict")
async def predict(input_data: InputData):
    model = joblib.load("backend/models/transformer_model.pkl")
    data = [[input_data.oti, input_data.wti, input_data.ati]]
    prediction = model.predict(data)
    return {"prediction": prediction}

app.include_router(router)

