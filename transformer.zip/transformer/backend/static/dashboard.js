document.getElementById('predict-btn').addEventListener('click', function() {
    fetch('/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            oti: document.getElementById('oti').value,
            wti: document.getElementById('wti').value,
            ati: document.getElementById('ati').value
        })
    })
    .then(response => response.json())
    .then(data => {
        alert("Prediction: " + data.prediction);
    });
});
