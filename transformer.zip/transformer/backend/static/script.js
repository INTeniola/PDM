// backend/static/scripts.js

document.addEventListener('DOMContentLoaded', function() {
    fetch('/api/metrics')
        .then(response => response.json())
        .then(data => {
            document.getElementById('metrics').innerHTML = `
                <p>Average Power Factor: ${data.avg_pf}</p>
                <p>Total KWH: ${data.total_kwh}</p>
                <!-- Add other metrics here -->
            `;
        });

    fetch('/api/alerts')
        .then(response => response.json())
        .then(alerts => {
            const alertsContainer = document.getElementById('alerts-container');
            alerts.forEach(alert => {
                const alertElement = document.createElement('div');
                alertElement.textContent = alert.message;
                alertElement.className = `alert ${alert.severity}`;
                alertsContainer.appendChild(alertElement);
            });
        });

    // Add additional code to render charts or other dynamic content
});
